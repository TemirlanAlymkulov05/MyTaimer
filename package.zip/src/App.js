import "./App.css";
import { Pomodoro1 } from "./components/Pomodoro1";
function App() {
  return (
    <div className="App">
      <Pomodoro1 />
    </div>
  );
}

export default App;
